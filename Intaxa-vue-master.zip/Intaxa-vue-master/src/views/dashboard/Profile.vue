<template>
  <div>
    <b-row>
      <b-col lg="9">
        <div class="pt-5 px-4 mt-5 text-left">
          <h3 class="mt-2 viga">Profile</h3>
        </div>
      </b-col>
    </b-row>
  </div>
</template>