<template>
  <div>
    <b-row>
      <b-col lg="9">
        <div class="pt-5 px-4 mt-5 text-left">
          <h3 class="mt-2 viga">Setting</h3>
          <div class="py-5 my-5 text-center">
            <img src="@/assets/img/illust/coming_soon.svg" width="350px" alt="Coming Soon">
            <h2 class="viga mt-4 mb-0">Coming Soon</h2>
            <p class="mt-1">Masih dalam tahap pengembangan</p>
          </div>
        </div>
      </b-col>
    </b-row>
  </div>
</template>